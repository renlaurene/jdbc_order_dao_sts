package edu.npu.orderApp;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.jdbc.core.JdbcTemplate;

import edu.npu.orderApp.config.OrderAppConfig;
import edu.npu.orderApp.dao.jdbc.OrderDaoJdbcImpl;
import edu.npu.orderApp.dao.jdbc.ProductDaoJdbcImpl;
import edu.npu.orderApp.domain.Order;

@SpringBootApplication
@Import(OrderAppConfig.class)  // This 
public class JdbcOrderexApplication implements CommandLineRunner {
	@Autowired
	JdbcTemplate dbtemplate;
	@Autowired
	OrderDaoJdbcImpl orderdao;
	@Autowired
	ProductDaoJdbcImpl productdao;
	Logger applicationLog = LoggerFactory.getLogger(JdbcOrderexApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(JdbcOrderexApplication.class, args);
	}
	
	@Override  // CommandLineRunner interface -- this method called from SpringApplication.run()
    public void run(String... args) throws Exception {
		Order retrievedOrder;
		int cnt;
		List<String> prodsWithLowOrderCnt;
		int orderIdToLookup = 2;  /* We'll try to find this order below */

		cnt = orderdao.getOrderCount();
		applicationLog.info("\n\nCurrent number of orders in customer order table: " + cnt);
		/* This customer id should already be in the database if you ran SQL script insertdata.sql  */
		retrievedOrder = orderdao.findOrderById(orderIdToLookup);
		if (retrievedOrder != null) {
			applicationLog.info("\nOrder retrieved from customer order table: " + retrievedOrder);
		} else {
			applicationLog.info("\nOrder id " + orderIdToLookup + " was not found in the order table");
		}
		
		cnt = productdao.getProductCount();
		applicationLog.info("Current number of products in product table: " + cnt + "\n");
		
		prodsWithLowOrderCnt = productdao.findProdsWithLessThanTotalOrder(3);
		applicationLog.info(prodsWithLowOrderCnt.size() + " products found to have a low order count:");
		for (String prodName: prodsWithLowOrderCnt) {
			applicationLog.info(prodName);
		}

        System.exit(0);
    }
}
