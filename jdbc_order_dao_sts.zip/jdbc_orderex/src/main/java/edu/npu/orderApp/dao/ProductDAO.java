package edu.npu.orderApp.dao;

import java.util.List;

public interface ProductDAO {
	public int getProductCount();
	int findTotalOrdersByName(String prodName);
	public List<String> findProdsWithLessThanTotalOrder(int orderCnt);
	public String findProdNameById(int id);
}
