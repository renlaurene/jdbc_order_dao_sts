package edu.npu.orderApp.dao.jdbc;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import edu.npu.orderApp.dao.ProductDAO;

@Repository("productDaoJdbc")
public class ProductDaoJdbcImpl implements ProductDAO {
	@Autowired
	@Qualifier("dataSource")
	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemplate;
	
	@PostConstruct
	public void setup() {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public int getProductCount() {
		String sql = "select count(*) from product";
		return jdbcTemplate.queryForObject(sql, Integer.class);
	}

	public int findTotalOrdersByName(String prodName) {
		String sql = "select totalOrders from product where name=?";
		return jdbcTemplate.queryForObject(sql, Integer.class, prodName);
	}
	
	public List<String> findProdsWithLessThanTotalOrder(int orderCnt) {
		String sql = "select name from product where totalOrders<?";
		return jdbcTemplate.queryForList(sql, String.class, orderCnt);
	}
	
	public String findProdNameById(int id) {
		String sql = "select name from product where id=?";
		return jdbcTemplate.queryForObject(sql, String.class, id);
	}
	
}
