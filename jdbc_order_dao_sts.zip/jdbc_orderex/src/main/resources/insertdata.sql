

CREATE TABLE `cusorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cusnum` varchar(15) NOT NULL,
  `date` date DEFAULT NULL,
  `amount` float DEFAULT NULL,
  PRIMARY KEY (`id`)
);


CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `totalOrders` int(10) DEFAULT NULL,
  `price` float unsigned  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

INSERT INTO `cusorder` (`cusnum`,`date`,`amount`) VALUES ('5B999','2019-03-21',100);
INSERT INTO `cusorder` (`cusnum`,`date`,`amount`) VALUES ('6C779','2019-11-03',200);

INSERT INTO `product` (`name`, `totalOrders`, `price`) VALUES ('Z500', '5', '99.99');
INSERT INTO `product` (`name`, `totalOrders`, `price`) VALUES ('Z502', '1', '998.99');
INSERT INTO `product` (`name`, `totalOrders`, `price`) VALUES ('X2200', '10', '53.67');
INSERT INTO `product` (`name`, `totalOrders`, `price`) VALUES ('Q2610', '2', '65.41');




