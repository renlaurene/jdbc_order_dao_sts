CREATE USER 'orderdb_user'@'localhost' IDENTIFIED BY 'spring';

GRANT ALL PRIVILEGES ON cs548_orders.* TO 'orderdb_user'@'localhost' WITH GRANT OPTION;

SHOW GRANTS FOR 'orderdb_user'@'localhost';